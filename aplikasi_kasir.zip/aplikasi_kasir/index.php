<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Login Kasir</title>

  <!-- Font & Icon -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

  <style>
    :root {
      --cream: #ffebc9ff;
      --dark-red: #800000;
      --light-red: #bb3030ff;
      --text-color: #840f0fff;
      --placeholder: #751212ff;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      height: 100vh;
      background: linear-gradient(to bottom right, var(--cream), var(--light-red));
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .login-container {
      background-color: var(--cream);
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
      width: 340px;
      text-align: center;
    }

    .login-container h2 {
      color: var(--dark-red);
      font-weight: 700;
      margin-bottom: 25px;
      font-size: 2rem;
    }

    .input-group {
      position: relative;
      margin-bottom: 20px;
      text-align: left;
    }

    .input-group i {
      position: absolute;
      top: 50%;
      left: 12px;
      transform: translateY(-50%);
      color: #b33b3b;
      font-size: 18px;
    }

    .input-group input {
      width: 100%;
      padding: 12px 12px 12px 40px;
      border: 1.5px solid #feead6ff;
      border-radius: 8px;
      background-color: #fffaf0;
      font-size: 1rem;
      color: var(--text-color);
      outline: none;
      transition: border-color 0.3s ease;
    }

    .input-group input::placeholder {
      color: var(--placeholder);
      font-style: italic;
    }

    .input-group input:focus {
      border-color: var(--dark-red);
    }

    .forgot {
      text-align: right;
      margin-bottom: 20px;
    }

    .forgot a {
      font-size: 0.9rem;
      color: var(--dark-red);
      text-decoration: none;
      transition: color 0.3s;
    }

    .forgot a:hover {
      color: #782c2cff;
      text-decoration: underline;
    }

    button {
      width: 100%;
      background-color: var(--dark-red);
      color: var(--cream);
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }

    button:hover {
      background-color: #a00000;
      transform: translateY(-2px);
    }
  </style>
</head>
<body>

  <div class="login-container" role="main" aria-label="Form Login">
    <h2>Login</h2>
    <form action="proses/proses_login.php" method="post" autocomplete="on" novalidate>
      <div class="input-group">
        <i class="fas fa-user"></i>
        <input
          type="text"
          name="username"
          placeholder="Masukkan username"
          required
          autocomplete="username"
          aria-label="Input username"
        />
      </div>

      <div class="input-group">
        <i class="fas fa-lock"></i>
        <input
          type="password"
          name="password"
          placeholder="Masukkan password"
          required
          autocomplete="current-password"
          aria-label="Input password"
        />
      </div>

      <div class="forgot">
        <a href="#" tabindex="0" aria-label="Lupa password">Lupa password?</a>
      </div>

      <button type="submit" aria-label="Tombol masuk">Masuk</button>
    </form>
  </div>

</body>
</html>

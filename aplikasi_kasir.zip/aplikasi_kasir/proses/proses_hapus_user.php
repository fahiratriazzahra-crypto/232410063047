<?php
include '../config/koneksi.php';

if (isset($_GET['id'])) {
    $id_user = $_GET['id'];

    $query = "DELETE FROM user WHERE UserID = $id_user";
    
    if (mysqli_query($koneksi, $query)) {
        header('Location: ../halaman/user.php?pesan=hapus_sukses');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
} else {
    header('Location: ../halaman/user.php');
}
?>
<?php
session_start();

function cekLogin() {
    if (!isset($_SESSION['UserID'])) {
        header("Location: ../index.php");
        exit();
    }
}

function hakAkses($level)
{
    if ($_SESSION['Level'] != $level) {
        //Arahkan ke halaman error ketika tidak memiliki akses
        header("Location: dashboard.php");
        exit();
    }
}

<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: produk.php');
    exit;
}
include '../config/koneksi.php';

include '../templates/header.php';
?>

<!-- Tambahkan Google Fonts Poppins -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
  body {
    background: #fff8e1 url('https://www.toptal.com/designers/subtlepatterns/patterns/diagmonds.png') repeat; /* Pola halus */
    font-family: 'Poppins', sans-serif;
    color: #5c0d0d;
    padding: 40px;
  }
  h2 {
    color: #7b1212;
    font-weight: 700;
    font-size: 2.5rem;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 3px;
    text-shadow: 2px 2px 6px rgba(123, 18, 18, 0.4);
  }
  .form-label {
    color: #7b1212;
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 8px;
  }
  .form-control {
    width: 100%;
    padding: 12px 40px 12px 15px; /* Space for icon */
    font-size: 1rem;
    color: #5c0d0d;
    background: #fff3d4;
    border: 2px solid;
    border-image-slice: 1;
    border-width: 2px;
    border-image-source: linear-gradient(45deg, #7b1212, #b02a2a);
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(123,18,18,0.15);
    transition: all 0.3s ease;
    position: relative;
  }
  .form-control:focus {
    outline: none;
    border-image-source: linear-gradient(45deg, #b02a2a, #7b1212);
    box-shadow: 0 0 12px #b02a2a;
    background: #fff6e1;
    color: #5c0d0d;
  }
  /* Icon inside input */
  .input-icon {
    position: absolute;
    right: 15px;
    top: 70%;
    transform: translateY(-50%);
    pointer-events: none;
    color: #b02a2a;
    font-size: 1.2rem;
    opacity: 0.6;
  }
  .form-group {
    position: relative;
    margin-bottom: 30px;
  }
  .btn-primary {
    background: linear-gradient(45deg, #7b1212, #b02a2a);
    border: none;
    color: #fff8e1;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 12px 30px;
    border-radius: 30px;
    cursor: pointer;
    box-shadow: 0 5px 15px rgba(176, 42, 42, 0.5);
    transition: all 0.4s ease;
  }
  .btn-primary:hover {
    background: linear-gradient(45deg, #b02a2a, #7b1212);
    box-shadow: 0 8px 20px rgba(176, 42, 42, 0.8);
    transform: scale(1.05);
  }
  .btn-secondary {
    background: #d9b382;
    color: #5c0d0d;
    border: 2px solid #b02a2a;
    font-weight: 600;
    padding: 12px 30px;
    border-radius: 30px;
    margin-left: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  .btn-secondary:hover {
    background: #c4a06b;
    color: #3f0606;
    border-color: #7b1212;
  }
  .col-md-6 {
    max-width: 600px;
    margin: 0 auto;
  }
</style>

<h2 style="text-align:center; color:#7b1212; font-weight:700; margin-bottom:30px;">Tambah Produk</h2>
<div class="row">
    <div class="col-md-6">
        <form action="../proses/proses_tambah_produk.php" method="POST" autocomplete="off">
            <div class="form-group">
                <label for="nama_produk" class="form-label">Nama Produk</label>
                <input type="text" class="form-control" id="nama_produk" name="nama_produk" required>
                <span class="input-icon">🛒</span>
            </div>
            <div class="form-group">
                <label for="harga" class="form-label">Harga</label>
                <input type="number" class="form-control" id="harga" name="harga" required>
                <span class="input-icon">💰</span>
            </div>
            <div class="form-group">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stok" name="stok" required>
                <span class="input-icon">📦</span>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="produk.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../templates/footer.php'; ?>

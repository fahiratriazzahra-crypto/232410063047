<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

$query_produk = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk WHERE Stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

$query_pelanggan = "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID != 1";
$result_pelanggan = mysqli_query($koneksi, $query_pelanggan);

include '../templates/header.php';
?>

<style>
  body {
    background: #f9f5f0; /* cream */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #6a1b1b; /* merah tua */
    padding: 20px;
  }

  h2 {
    text-align: center;
    color: #6a1b1b;
    font-weight: 900;
    font-size: 3rem;
    margin-bottom: 30px;
    text-shadow: 1.5px 1.5px 3px #b94e4e80;
    letter-spacing: 3px;
  }

  label {
    font-weight: 700;
    font-size: 1.1rem;
    color: #7a2323;
    margin-bottom: 0.4rem;
  }

  select.form-control,
  input.form-control {
    border-radius: 12px;
    border: 2px solid #7a2323;
    background: #fdf7f2;
    color: #6a1b1b;
    padding: 0.6rem 1rem;
    font-weight: 600;
    font-size: 1rem;
    transition: 0.3s ease;
  }

  select.form-control:focus,
  input.form-control:focus {
    outline: none;
    border-color: #b42c2c;
    box-shadow: 0 0 8px #b42c2c70;
    background: #fff8f5;
  }

  .btn-primary {
    background: #7a2323;
    border: none;
    color: #f9f5f0;
    font-weight: 900;
    font-size: 1.1rem;
    border-radius: 12px;
    padding: 0.6rem 1.2rem;
    box-shadow: 0 4px 10px #b42c2c80;
    transition: all 0.3s ease;
    width: 100%;
  }

  .btn-primary:hover {
    background: #b42c2c;
    box-shadow: 0 6px 14px #b42c2cbb;
    transform: translateY(-2px);
  }

  .btn-success {
    background: #7a2323;
    color: #f9f5f0;
    border-radius: 12px;
    font-weight: 900;
    font-size: 1.25rem;
    padding: 0.8rem;
    width: 100%;
    border: none;
    margin-top: 20px;
    box-shadow: 0 5px 15px #b42c2c99;
    transition: background-color 0.3s ease;
  }

  .btn-success:disabled {
    background: #c7b7b7;
    cursor: not-allowed;
    box-shadow: none;
  }

  .btn-success:not(:disabled):hover {
    background: #b42c2c;
  }

  hr {
    border: none;
    border-top: 2.5px solid #7a2323;
    margin: 2.5rem 0;
    border-radius: 8px;
  }

  h4 {
    font-weight: 800;
    font-size: 1.7rem;
    margin-bottom: 20px;
    color: #7a2323;
    letter-spacing: 1.2px;
  }

  /* Table Styling */
  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 10px;
    background: #fdf7f2;
    box-shadow: 0 5px 15px #b42c2c50;
    border-radius: 15px;
    overflow: hidden;
  }

  thead tr {
    background: #7a2323;
    color: #f9f5f0;
    font-weight: 800;
    font-size: 1.1rem;
    letter-spacing: 1.5px;
  }

  tbody tr {
    background: #fff8f5;
    font-weight: 600;
    font-size: 1rem;
    transition: background-color 0.3s ease;
    border-radius: 12px;
  }

  tbody tr:hover {
    background: #ffe5e5;
  }

  th, td {
    text-align: center;
    padding: 1rem 1.2rem;
  }

  input.jumlah-keranjang {
    width: 70px;
    font-weight: 700;
    text-align: center;
    border-radius: 10px;
    border: 1.8px solid #7a2323;
    background: #fdf7f2;
    color: #6a1b1b;
  }

  /* Responsive */
  @media(max-width: 768px) {
    h2 {
      font-size: 2.2rem;
    }
    h4 {
      font-size: 1.3rem;
    }
  }
</style>

<h2>Transaksi Penjualan</h2>

<form action="../proses/proses_penjualan.php" method="POST" autocomplete="off">
  <div class="form-group mb-4">
    <label for="pelanggan_id">Pelanggan</label>
    <select name="pelanggan_id" class="form-control" required>
      <option value="" selected disabled>-- Pilih Pelanggan --</option>
      <?php while($row_pelanggan = mysqli_fetch_assoc($result_pelanggan)): ?>
        <option value="<?= $row_pelanggan['PelangganID']; ?>"><?= htmlspecialchars($row_pelanggan['NamaPelanggan']); ?></option>
      <?php endwhile; ?>
    </select>
  </div>

  <hr>

  <h4>Pilih Barang</h4>
  <div class="form-row mb-4 d-flex flex-wrap gap-3 align-items-end">
    <div style="flex: 1 1 40%;">
      <label for="produk_input">Produk</label>
      <select id="produk_input" class="form-control" aria-label="Pilih produk">
        <option value="" selected>-- Pilih Produk --</option>
        <?php mysqli_data_seek($result_produk, 0); ?>
        <?php while($row_produk = mysqli_fetch_assoc($result_produk)): ?>
          <option value="<?= $row_produk['ProdukID']; ?>"
                  data-harga="<?= $row_produk['Harga']; ?>"
                  data-nama="<?= htmlspecialchars($row_produk['NamaProduk']); ?>"
                  data-stok="<?= $row_produk['Stok']; ?>">
            <?= htmlspecialchars($row_produk['NamaProduk']); ?> (Stok: <?= $row_produk['Stok']; ?>)
          </option>
        <?php endwhile; ?>
      </select>
    </div>

    <div style="flex: 1 1 20%;">
      <label for="jumlah_input">Jumlah</label>
      <input type="number" id="jumlah_input" class="form-control" min="1" value="1" aria-label="Jumlah produk">
    </div>

    <div style="flex: 1 1 30%;">
      <button type="button" class="btn btn-primary" id="tambah-keranjang" aria-label="Tambah produk ke keranjang">Tambah ke Keranjang</button>
    </div>
  </div>

  <hr>

  <h4>Keranjang Belanja</h4>
  <div class="table-responsive">
    <table aria-label="Keranjang belanja">
      <thead>
        <tr>
          <th>Produk</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Subtotal</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="keranjang-body"></tbody>
      <tfoot>
        <tr>
          <td colspan="3" class="text-right" style="font-weight: 800;">Total Harga</td>
          <td colspan="2" style="font-weight: 800;" id="total-harga-display">Rp 0</td>
        </tr>
      </tfoot>
    </table>
  </div>

  <div id="keranjang-inputs"></div>

  <input type="hidden" name="total_harga" id="total_harga" value="0">
  <button type="submit" class="btn btn-success" id="simpan-transaksi" disabled>Simpan Transaksi</button>
</form>

<?php
include '../templates/footer.php';
?>

<script>
$(document).ready(function() {
    let keranjang = {};

    function hitungTotal() {
        let total = 0;
        for (const id in keranjang) {
            total += keranjang[id].subtotal;
        }
        $('#total-harga-display').text('Rp ' + total.toLocaleString('id-ID'));
        $('#total_harga').val(total);
        
        if (Object.keys(keranjang).length > 0) {
            $('#simpan-transaksi').removeAttr('disabled');
        } else {
            $('#simpan-transaksi').attr('disabled', 'disabled');
        }
    }

    function renderKeranjang() {
        $('#keranjang-body').empty();
        $('#keranjang-inputs').empty();

        for (const id in keranjang) {
            const item = keranjang[id];
            const row = `
                <tr>
                    <td>${item.nama}</td>
                    <td>Rp ${item.harga.toLocaleString('id-ID')}</td>
                    <td>
                        <input type="number" class="form-control jumlah-keranjang" data-id="${item.id}" value="${item.jumlah}" min="1" max="${item.stok}">
                    </td>
                    <td>Rp ${item.subtotal.toLocaleString('id-ID')}</td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm hapus-keranjang" data-id="${item.id}">Hapus</button>
                    </td>
                </tr>
            `;
            $('#keranjang-body').append(row);

            const inputHidden = `
                <input type="hidden" name="produk_id[]" value="${item.id}">
                <input type="hidden" name="jumlah[]" value="${item.jumlah}">
            `;
            $('#keranjang-inputs').append(inputHidden);
        }
        hitungTotal();
    }

    $('#tambah-keranjang').click(function() {
        const produkInput = $('#produk_input');
        const jumlahInput = $('#jumlah_input');

        const produkID = produkInput.val();
        const jumlah = parseInt(jumlahInput.val());
        const harga = parseFloat(produkInput.find('option:selected').data('harga'));
        const nama = produkInput.find('option:selected').data('nama');
        const stok = parseInt(produkInput.find('option:selected').data('stok'));

        if (produkID && jumlah > 0 && jumlah <= stok) {
            if (keranjang[produkID]) {
                const newJumlah = keranjang[produkID].jumlah + jumlah;
                if (newJumlah > stok) {
                    alert('Jumlah melebihi stok yang tersedia!');
                    return;
                }
                keranjang[produkID].jumlah = newJumlah;
                keranjang[produkID].subtotal = newJumlah * harga;
            } else {
                keranjang[produkID] = {
                    id: produkID,
                    nama: nama,
                    harga: harga,
                    jumlah: jumlah,
                    stok: stok,
                    subtotal: harga * jumlah
                };
            }
            renderKeranjang();
        } else if (jumlah > stok) {
            alert('Jumlah melebihi stok yang tersedia!');
        } else {
            alert('Silakan pilih produk dan jumlah yang valid.');
        }
    });

    $(document).on('click', '.hapus-keranjang', function() {
        const produkID = $(this).data('id');
        delete keranjang[produkID];
        renderKeranjang();
    });

    $(document).on('change', '.jumlah-keranjang', function() {
        const produkID = $(this).data('id');
        const newJumlah = parseInt($(this).val());
        const stok = keranjang[produkID].stok;

        if (newJumlah <= 0 || newJumlah > stok) {
            alert('Jumlah tidak valid atau melebihi stok!');
            $(this).val(keranjang[produkID].jumlah);
            return;
        }

        keranjang[produkID].jumlah = newJumlah;
        keranjang[produkID].subtotal = newJumlah * keranjang[produkID].harga;
        renderKeranjang();
    });
});
</script>

<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Cek level pengguna
$level_user = $_SESSION['Level'];

// Ambil data pelanggan dari database
$query = "SELECT * FROM pelanggan";
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';
?>

<style>
  body {
    background-color: #f5f1e9; /* cream */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }
  h2 {
    color: #7b1e23; /* merah tua */
    font-weight: 700;
    margin-bottom: 1.5rem;
    text-align: center;
  }
  .btn-primary {
    background-color: #7b1e23; /* merah tua */
    border-color: #7b1e23;
    font-weight: 700;
    transition: background-color 0.3s ease;
  }
  .btn-primary:hover {
    background-color: #a42a2f;
    border-color: #a42a2f;
  }
  .btn-secondary {
    background-color: #f5f1e9; /* cream */
    color: #7b1e23;
    border: 2px solid #7b1e23;
    font-weight: 600;
  }
  .btn-secondary:hover {
    background-color: #7b1e23;
    color: #f5f1e9;
  }
  .btn-warning {
    background-color: #d4a017;
    border-color: #d4a017;
    color: #fff;
    font-weight: 600;
  }
  .btn-warning:hover {
    background-color: #b8860b;
    border-color: #b8860b;
  }
  .btn-danger {
    background-color: #7b1e23;
    border-color: #7b1e23;
    font-weight: 600;
  }
  .btn-danger:hover {
    background-color: #a42a2f;
    border-color: #a42a2f;
  }
  .table {
    background-color: #fff8f6; /* very light cream */
    border: 2px solid #7b1e23;
    border-radius: 8px;
  }
  .table th, .table td {
    color: #7b1e23;
    font-weight: 600;
    vertical-align: middle;
    border-color: #7b1e23;
  }
  .table thead {
    background-color: #7b1e23;
    color: #f5f1e9;
    font-weight: 700;
  }
  .row.mb-3 .col {
    display: flex;
    align-items: center;
  }
  .row.mb-3 .col.text-end {
    justify-content: flex-end;
  }
</style>

<h2>Manajemen Pelanggan</h2>
<div class="row mb-3">
    <div class="col">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
    <?php if ($level_user == 'petugas'): ?>
    <div class="col text-end">
        <a href="tambah_pelanggan.php" class="btn btn-primary">Tambah Pelanggan</a>
    </div>
    <?php endif; ?>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pelanggan</th>
                <th>Alamat</th>
                <th>Nomor Telepon</th>
                <?php if ($level_user == 'petugas'): ?>
                <th>Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while($row = mysqli_fetch_assoc($result)):
                // Jangan tampilkan Pelanggan Umum di daftar
                if ($row['PelangganID'] != 1):
            ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['NamaPelanggan']; ?></td>
                <td><?= $row['Alamat']; ?></td>
                <td><?= $row['NomorTelepon']; ?></td>
                <?php if ($level_user == 'petugas'): ?>
                <td>
                    <a href="edit_pelanggan.php?id=<?= $row['PelangganID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="../proses/proses_hapus_pelanggan.php?id=<?= $row['PelangganID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini?');">Hapus</a>
                </td>
                <?php endif; ?>
            </tr>
            <?php
                endif;
            endwhile;
            ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>

<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: user.php');
    exit;
}
include '../config/koneksi.php';

include '../templates/header.php';
?>

<!-- Google Fonts Poppins -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
  body {
    background: #fff8e1 url('https://www.toptal.com/designers/subtlepatterns/patterns/diagmonds.png') repeat;
    font-family: 'Poppins', sans-serif;
    color: #5c0d0d;
    padding: 40px;
  }
  h2 {
    color: #7b1212;
    font-weight: 700;
    font-size: 2.5rem;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 3px;
    text-shadow: 2px 2px 6px rgba(123, 18, 18, 0.4);
  }
  .form-label {
    color: #7b1212;
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 8px;
  }
  .form-control, .form-select {
    width: 100%;
    padding: 12px 40px 12px 15px;
    font-size: 1rem;
    color: #5c0d0d;
    background: #fff3d4;
    border: 2px solid;
    border-image-slice: 1;
    border-width: 2px;
    border-image-source: linear-gradient(45deg, #7b1212, #b02a2a);
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(123,18,18,0.15);
    transition: all 0.3s ease;
    position: relative;
  }
  .form-control:focus, .form-select:focus {
    outline: none;
    border-image-source: linear-gradient(45deg, #b02a2a, #7b1212);
    box-shadow: 0 0 12px #b02a2a;
    background: #fff6e1;
    color: #5c0d0d;
  }
  .form-group {
    position: relative;
    margin-bottom: 50px;
  }
  .input-icon {
    position: absolute;
    right: 15px;
    top: 70%;
    transform: translateY(-50%);
    pointer-events: none;
    color: #b02a2a;
    font-size: 1.2rem;
    opacity: 0.6;
  }
  .btn-primary {
    background: linear-gradient(45deg, #7b1212, #b02a2a);
    border: none;
    color: #fff8e1;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 12px 30px;
    border-radius: 30px;
    cursor: pointer;
    box-shadow: 0 5px 15px rgba(176, 42, 42, 0.5);
    transition: all 0.4s ease;
  }
  .btn-primary:hover {
    background: linear-gradient(45deg, #b02a2a, #7b1212);
    box-shadow: 0 8px 20px rgba(176, 42, 42, 0.8);
    transform: scale(1.05);
  }
  .btn-secondary {
    background: #d9b382;
    color: #5c0d0d;
    border: 2px solid #b02a2a;
    font-weight: 600;
    padding: 12px 30px;
    border-radius: 30px;
    margin-left: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
  }
  .btn-secondary:hover {
    background: #c4a06b;
    color: #3f0606;
    border-color: #7b1212;
  }
  .col-md-6 {
    max-width: 600px;
    margin: 0 auto;
  }
</style>

<h2 style="text-align:center; color:#7b1212; font-weight:700; margin-bottom:30px;">Tambah User</h2>
<div class="row">
    <div class="col-md-6">
        <form action="../proses/proses_tambah_user.php" method="POST" autocomplete="off">
            <div class="form-group">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
                <span class="input-icon">👤</span>
            </div>
            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
                <span class="input-icon">🔒</span>
            </div>
            <div class="form-group">
                <label for="level" class="form-label">Level</label>
                <select class="form-select" id="level" name="level" required>
                    <option value="administrator">Administrator</option>
                    <option value="petugas">Petugas</option>
                </select>
                <span class="input-icon">⚙️</span>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="user.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../templates/footer.php'; ?>

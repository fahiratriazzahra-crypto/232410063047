<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: dashboard.php');
    exit;
}
include '../config/koneksi.php';

// Ambil data user dari database
$query = "SELECT UserID, Username, Level FROM user";
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';

// Pesan sukses/error
if (isset($_GET['pesan'])) {
    $pesan = $_GET['pesan'];
    if ($pesan == 'sukses') {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data user berhasil disimpan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    } elseif ($pesan == 'edit_sukses') {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">Data user berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    } elseif ($pesan == 'hapus_sukses') {
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">Data user berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
}
?>

<!-- Google Fonts Poppins -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
  body {
    background: #fff8e1;
    font-family: 'Poppins', sans-serif;
    color: #5c0d0d;
    padding: 40px;
  }
  h2 {
    color: #7b1212;
    font-weight: 700;
    font-size: 2.5rem;
    margin-bottom: 30px;
    text-transform: uppercase;
    letter-spacing: 3px;
    text-shadow: 2px 2px 6px rgba(123, 18, 18, 0.4);
    text-align: center;
  }
  .btn-primary, .btn-secondary, .btn-warning, .btn-danger {
    border-radius: 30px;
    font-weight: 600;
    padding: 10px 25px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(123, 18, 18, 0.3);
    border: none;
    cursor: pointer;
  }
  .btn-primary {
    background: linear-gradient(45deg, #7b1212, #b02a2a);
    color: #fff8e1;
  }
  .btn-primary:hover {
    background: linear-gradient(45deg, #b02a2a, #7b1212);
    box-shadow: 0 6px 18px rgba(176, 42, 42, 0.7);
    transform: scale(1.05);
  }
  .btn-secondary {
    background: #d9b382;
    color: #5c0d0d;
    box-shadow: 0 4px 10px rgba(176, 42, 42, 0.3);
  }
  .btn-secondary:hover {
    background: #c4a06b;
    color: #3f0606;
    box-shadow: 0 6px 16px rgba(123, 18, 18, 0.5);
  }
  .btn-warning {
    background: #f0ad4e;
    color: #5c0d0d;
    box-shadow: 0 4px 10px rgba(123, 70, 18, 0.3);
  }
  .btn-warning:hover {
    background: #d6952d;
    box-shadow: 0 6px 16px rgba(123, 70, 18, 0.6);
  }
  .btn-danger {
    background: #b02a2a;
    color: #fff8e1;
    box-shadow: 0 4px 10px rgba(176, 42, 42, 0.4);
  }
  .btn-danger:hover {
    background: #7b1212;
    box-shadow: 0 6px 16px rgba(123, 18, 18, 0.7);
  }
  .btn:focus {
    outline: none;
  }

  .row.mb-3 {
    max-width: 900px;
    margin: 0 auto 30px auto;
    display: flex;
    justify-content: space-between;
  }

  /* Tabel styling */
  .table-responsive {
    max-width: 900px;
    margin: 0 auto;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(123, 18, 18, 0.2);
    background: #fff3d4;
  }
  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
  }
  thead {
    background: linear-gradient(45deg, #7b1212, #b02a2a);
    color: #fff8e1;
    font-weight: 700;
  }
  thead th {
    padding: 15px 20px;
    text-align: left;
    letter-spacing: 1.5px;
  }
  tbody tr {
    background: #fff8e1;
    transition: background-color 0.3s ease;
  }
  tbody tr:hover {
    background: #f9e8d3;
  }
  tbody td {
    padding: 15px 20px;
    color: #5c0d0d;
    border-bottom: 1px solid #d9b382;
    vertical-align: middle;
  }

  /* Nomor (No) column */
thead th:last-child {
  text-align: center;
}
tbody td:last-child {
  text-align: center;
  vertical-align: middle;
  display: flex;
  justify-content: center;
  gap: 10px;
  align-items: center;
  padding: 12px 20px;
}
tbody td:last-child a.btn {
  min-width: 70px;
}

</style>

<h2>Manajemen User</h2>
<div class="row mb-3">
    <div class="col">
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
    </div>
    <div class="col text-end">
        <a href="tambah_user.php" class="btn btn-primary">Tambah User</a>
    </div>
</div>

<div class="table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Level</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['Username']); ?></td>
                <td><?= htmlspecialchars(ucfirst($row['Level'])); ?></td>
                <td>
                    <a href="edit_user.php?id=<?= $row['UserID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="../proses/proses_hapus_user.php?id=<?= $row['UserID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?');">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>

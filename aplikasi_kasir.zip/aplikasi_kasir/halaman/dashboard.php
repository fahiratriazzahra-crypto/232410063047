<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../templates/header.php';
?>

<style>
  body {
    background: #eaded2ff;
    font-family: 'Poppins', sans-serif;
    margin: 0;
    min-height: 100vh;
    color: #333;
  }

  header {
    display: flex;
    align-items: center;
    padding: 20px 40px;
    background-color: #800000;
    color: white;
    box-shadow: 0 2px 8px rgb(128 0 0 / 0.2);
  }

  .logo {
    max-width: 50px;
    margin-right: 20px;
    filter: drop-shadow(0 1px 1px rgba(0,0,0,0.2));
  }

  .welcome-text {
    font-weight: 700;
    font-size: 1.8rem;
    user-select: none;
  }

  .subheading {
    margin-top: 4px;
    font-weight: 500;
    font-size: 1rem;
    opacity: 0.8;
  }

  main.container {
    max-width: 900px;
    margin: 40px auto;
    padding: 0 20px;
  }

  .cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 28px;
  }

  .card {
    background: white;
    border-radius: 14px;
    box-shadow: 0 6px 20px rgba(128, 0, 0, 0.1);
    padding: 28px 24px;
    transition: box-shadow 0.3s ease, transform 0.3s ease;
    cursor: default;
  }

  .card:hover {
    box-shadow: 0 12px 35px rgba(128, 0, 0, 0.2);
    transform: translateY(-6px);
  }

  .card-title {
    font-weight: 700;
    font-size: 1.2rem;
    color: #800000;
    margin-bottom: 10px;
    letter-spacing: 0.04em;
  }

  .card-text {
    font-weight: 900;
    font-size: 3rem;
    color: #c53030;
    margin-bottom: 20px;
    user-select: text;
  }

  .btn-outline {
    display: inline-block;
    font-weight: 600;
    font-size: 1rem;
    padding: 0.55rem 1.2rem;
    border: 2px solid #800000;
    border-radius: 12px;
    background: transparent;
    color: #800000;
    text-decoration: none;
    transition: all 0.3s ease;
    user-select: none;
  }

  .btn-outline:hover {
    background-color: #800000;
    color: white;
    box-shadow: 0 5px 15px rgba(128, 0, 0, 0.3);
  }

  @media (max-width: 480px) {
    header {
      flex-direction: column;
      align-items: flex-start;
      gap: 8px;
      padding: 16px 20px;
    }

    .welcome-text {
      font-size: 1.4rem;
    }
  }
</style>

<header>
  <img src="../assets/logo.png" alt="Logo Perusahaan" class="logo" />
  <div>
    <div class="welcome-text">Hallo,Selamat Datang <?= htmlspecialchars($_SESSION['Username']); ?>!</div>
    <div class="subheading">Anda login sebagai <strong><?= htmlspecialchars($_SESSION['Level']); ?></strong></div>
  </div>
</header>

<main class="container">
  <div class="cards">
    <div class="card">
      <h3 class="card-title">Jumlah Produk</h3>
      <p class="card-text">10</p>
      <a href="produk.php" class="btn-outline" role="button">Lihat Detail</a>
    </div>
    <div class="card">
      <h3 class="card-title">Total Transaksi Hari Ini</h3>
      <p class="card-text">0</p>
      <a href="penjualan.php" class="btn-outline" role="button">Lihat Detail</a>
    </div>
  </div>
</main>

<?php
include '../templates/footer.php';
?>

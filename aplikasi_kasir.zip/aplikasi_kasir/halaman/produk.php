<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil kata kunci pencarian dari URL jika ada
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Query produk dengan filter pencarian
$query = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk";
if (!empty($search_query)) {
    $safe_search = mysqli_real_escape_string($koneksi, $search_query);
    $query .= " WHERE NamaProduk LIKE '%$safe_search%'";
}
$result = mysqli_query($koneksi, $query);

include '../templates/header.php';

// Pesan sukses atau error
if (isset($_GET['pesan'])) {
    $pesan = $_GET['pesan'];
    if ($pesan === 'sukses') {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Produk berhasil ditambahkan! 🎉
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    } elseif ($pesan === 'edit_sukses') {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Produk berhasil diperbarui! ✏️
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    } elseif ($pesan === 'hapus_sukses') {
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            Produk berhasil dihapus 🗑️
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
    }
}
?>

<!-- Google Fonts (Poppins) -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
  body {
    background: #fff7eb; /* soft cream */
    font-family: 'Poppins', sans-serif;
    color: #6e1a1a; /* deep maroon */
    padding: 40px 20px;
  }

  h2 {
    font-weight: 700;
    font-size: 2.8rem;
    margin-bottom: 2rem;
    text-align: center;
    letter-spacing: 2px;
    color: #7c1d1d;
    text-shadow: 1px 1px 3px rgba(124, 29, 29, 0.3);
  }

  .btn-primary, .btn-warning, .btn-danger, .btn-outline-success {
    border-radius: 25px;
    font-weight: 600;
    padding: 10px 25px;
    box-shadow: 0 4px 10px rgba(124, 29, 29, 0.2);
    transition: all 0.3s ease;
    border: none;
  }

  .btn-primary {
    background: linear-gradient(135deg, #7c1d1d, #c33939);
    color: #fff7eb;
  }
  .btn-primary:hover {
    background: linear-gradient(135deg, #c33939, #7c1d1d);
    box-shadow: 0 6px 20px rgba(195, 57, 57, 0.6);
    transform: scale(1.05);
  }

  .btn-outline-success {
    border: 2px solid #7c1d1d;
    background: transparent;
    color: #7c1d1d;
  }
  .btn-outline-success:hover {
    background: #7c1d1d;
    color: #fff7eb;
  }

  .btn-warning {
    background: #d4a017;
    color: #fff7eb;
  }

  .btn-danger {
    background: #7c1d1d;
    color: #fff7eb;
  }
  .btn-danger:hover {
    background: #c33939;
  }

  /* Form */
  .form-control {
    border: 2px solid #7c1d1d;
    border-radius: 15px;
    font-weight: 600;
    color: #7c1d1d;
    padding: 10px 15px;
    transition: all 0.3s ease;
  }
  .form-control::placeholder {
    color: #b77a7a;
  }
  .form-control:focus {
    outline: none;
    border-color: #c33939;
    box-shadow: 0 0 8px rgba(195, 57, 57, 0.5);
  }

  /* Layout for top controls */
  .row.mb-3 {
    max-width: 1000px;
    margin: 0 auto 2rem auto;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
  }

  /* Table */
  .table-responsive {
    max-width: 1000px;
    margin: 0 auto;
    box-shadow: 0 12px 30px rgba(124, 29, 29, 0.15);
    border-radius: 20px;
    overflow: hidden;
  }
  table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    background: #fff7eb;
  }
  thead {
    background: linear-gradient(135deg, #7c1d1d, #c33939);
    color: #fff7eb;
    font-weight: 700;
  }
  thead th {
    padding: 15px 25px;
    letter-spacing: 1.5px;
    text-align: left;
  }
  thead th:last-child {
    text-align: center; /* header aksi */
  }
  tbody tr {
    transition: background-color 0.25s ease;
    cursor: default;
  }
  tbody tr:hover {
    background: #f9e8d7;
  }
  tbody td {
    padding: 15px 25px;
    color: #6e1a1a;
    font-weight: 600;
    border-bottom: 1px solid #f0d8c2;
    vertical-align: middle;
  }
  tbody td:first-child {
    width: 60px;
  }
  tbody td:last-child {
    text-align: center;
    display: flex;
    justify-content: center;
    gap: 12px;
    align-items: center;
  }
  tbody td:last-child a.btn {
    min-width: 75px;
    font-size: 0.9rem;
    box-shadow: 0 3px 8px rgba(124, 29, 29, 0.2);
  }

  /* Responsive tweaks */
  @media (max-width: 768px) {
    .row.mb-3 {
      flex-direction: column;
      gap: 12px;
    }
    thead th, tbody td {
      padding: 12px 15px;
    }
    tbody td:last-child {
      flex-direction: column;
      gap: 6px;
    }
    tbody td:last-child a.btn {
      width: 100%;
    }
  }
</style>

<h2>Manajemen Produk</h2>
<div class="row mb-3 align-items-center">
    <div>
        <?php if ($_SESSION['Level'] == 'administrator'): ?>
            <a href="tambah_produk.php" class="btn btn-primary" title="Tambah produk baru">Tambah Produk</a>
        <?php endif; ?>
    </div>
    <div>
        <form action="" method="GET" class="d-flex" role="search" autocomplete="off">
            <input class="form-control me-2" type="search" placeholder="Cari produk..." aria-label="Search" name="search" value="<?= htmlspecialchars($search_query); ?>">
            <button class="btn btn-outline-success" type="submit" aria-label="Cari produk">Cari</button>
        </form>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <?php if ($_SESSION['Level'] == 'administrator'): ?>
                <th>Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['NamaProduk']); ?></td>
                <td>Rp <?= number_format($row['Harga'], 0, ',', '.'); ?></td>
                <td><?= $row['Stok']; ?></td>
                <?php if ($_SESSION['Level'] == 'administrator'): ?>
                <td>
                    <a href="edit_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-warning btn-sm" title="Edit produk">Edit</a>
                    <a href="../proses/proses_hapus_produk.php?id=<?= $row['ProdukID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus produk ini?');" title="Hapus produk">Hapus</a>
                </td>
                <?php endif; ?>
            </tr>
            <?php endwhile; ?>
            <?php if (mysqli_num_rows($result) == 0): ?>
            <tr>
              <td colspan="<?= $_SESSION['Level'] == 'administrator' ? 5 : 4 ?>" style="text-align:center; font-weight:600; padding: 25px 0; color:#a42a2f;">
                Produk tidak ditemukan 😔
              </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>

<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: user.php');
    exit;
}
include '../config/koneksi.php';

$id_user = $_GET['id'];
$query = "SELECT UserID, Username, Level FROM user WHERE UserID = $id_user";
$result = mysqli_query($koneksi, $query);
$data_user = mysqli_fetch_assoc($result);

include '../templates/header.php';
?>

<style>
  body {
    background-color: #f5f1e9; /* cream */
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }
  h2 {
    color: #7b1e23; /* merah tua */
    font-weight: 700;
    text-align: center;
    margin-bottom: 2rem;
  }
  .form-label {
    color: #7b1e23; /* merah tua */
    font-weight: 600;
  }
  .form-control, .form-select {
    background-color: #fff8f6; /* very light cream */
    border: 2px solid #7b1e23; /* merah tua */
    color: #7b1e23;
    font-weight: 600;
  }
  .form-control:focus, .form-select:focus {
    border-color: #a42a2f; /* sedikit lebih terang merah */
    box-shadow: 0 0 5px #a42a2f;
  }
  .btn-primary {
    background-color: #7b1e23; /* merah tua */
    border-color: #7b1e23;
    font-weight: 700;
    transition: background-color 0.3s ease;
  }
  .btn-primary:hover {
    background-color: #a42a2f; /* hover lebih terang */
    border-color: #a42a2f;
  }
  .btn-secondary {
    background-color: #f5f1e9; /* cream */
    color: #7b1e23;
    border: 2px solid #7b1e23;
    font-weight: 600;
  }
  .btn-secondary:hover {
    background-color: #7b1e23;
    color: #f5f1e9;
  }
  .row {
    justify-content: center;
  }
  .col-md-6 {
    background-color: #fff8f6;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(123, 30, 35, 0.2);
  }
</style>

<h2>Edit User</h2>
<div class="row">
    <div class="col-md-6">
        <form action="../proses/proses_edit_user.php" method="POST">
            <input type="hidden" name="id" value="<?= $data_user['UserID']; ?>">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?= $data_user['Username']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="level" class="form-label">Level</label>
                <select class="form-select" id="level" name="level" required>
                    <option value="administrator" <?= ($data_user['Level'] == 'administrator') ? 'selected' : ''; ?>>Administrator</option>
                    <option value="petugas" <?= ($data_user['Level'] == 'petugas') ? 'selected' : ''; ?>>Petugas</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="user.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<?php include '../templates/footer.php'; ?>

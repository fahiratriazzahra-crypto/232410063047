<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// (Logika update stok ada di proses_stok.php)

include '../templates/header.php';
?>

<style>
  body {
    background-color: #f5f1e9; /* cream */
  }
  h2 {
    color: #7b1e23; /* merah tua */
    font-weight: 700;
    margin-bottom: 2rem;
    text-align: center;
  }
  .table {
    background-color: #fff8f6;
    border: 2px solid #7b1e23;
    border-radius: 8px;
  }
  .table th, .table td {
    color: #7b1e23;
    font-weight: 600;
    border-color: #7b1e23;
    vertical-align: middle;
  }
  .btn-primary {
    background-color: #7b1e23;
    border-color: #7b1e23;
    font-weight: 600;
  }
  .btn-primary:hover {
    background-color: #a42a2f;
    border-color: #a42a2f;
  }
  input[type=number] {
    border: 2px solid #7b1e23;
    border-radius: 6px;
    font-weight: 600;
    color: #7b1e23;
    width: 100px;
    padding: 4px 8px;
  }
  input[type=number]:focus {
    border-color: #a42a2f;
    box-shadow: 0 0 5px #a42a2f;
    outline: none;
  }
</style>

<div class="container mt-5">
    <h2>Update Stok Barang</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Nama Produk</th>
                <th>Stok Saat Ini</th>
                <th>Tambah Stok</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query_stok = "SELECT * FROM produk";
            $result_stok = mysqli_query($koneksi, $query_stok);
            while($row = mysqli_fetch_assoc($result_stok)):
            ?>
            <tr>
                <td><?= htmlspecialchars($row['NamaProduk']); ?></td>
                <td><?= $row['Stok']; ?></td>
                <td>
                    <form action="../proses/proses_stok.php" method="POST" class="d-flex align-items-center">
                        <input type="number" name="tambah_stok" min="0" value="0" required>
                        <input type="hidden" name="id_produk" value="<?= $row['ProdukID']; ?>">
                </td>
                <td>
                        <button type="submit" class="btn btn-sm btn-primary ms-2">Update</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../templates/footer.php'; ?>

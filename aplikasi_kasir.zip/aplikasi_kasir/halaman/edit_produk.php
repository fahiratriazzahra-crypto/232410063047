<?php
include '../fungsi/autentikasi.php';
cekLogin();
if ($_SESSION['Level'] != 'administrator') {
    header('Location: produk.php');
    exit;
}
include '../config/koneksi.php';

// Ambil data produk berdasarkan ID
$id_produk = $_GET['id'];
$query = "SELECT * FROM produk WHERE ProdukID = $id_produk";
$result = mysqli_query($koneksi, $query);
$data_produk = mysqli_fetch_assoc($result);

include '../templates/header.php';
?>

<style>
  body {
    background-color: #fef9f4;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  h2 {
    color: #800000;
    font-weight: 900;
    font-size: 2.4rem;
    text-align: center;
    margin: 30px 0 40px;
    letter-spacing: 1.2px;
    user-select: none;
  }

  .edit-form {
    max-width: 540px;
    margin: 0 auto 60px;
    background: #fff7e6;
    border-radius: 20px;
    padding: 30px 40px;
    box-shadow: 0 10px 30px rgba(128, 0, 0, 0.15);
    border: 2px solid #800000;
    transition: box-shadow 0.3s ease;
  }

  .edit-form:hover {
    box-shadow: 0 16px 40px rgba(128, 0, 0, 0.3);
  }

  label {
    font-weight: 700;
    color: #800000;
    margin-bottom: 6px;
    user-select: none;
  }

  input.form-control {
    border: 2.5px solid #d8c9b3;
    border-radius: 12px;
    padding: 12px 14px;
    font-size: 1.1rem;
    transition: border-color 0.3s ease;
  }

  input.form-control:focus {
    border-color: #800000;
    box-shadow: 0 0 8px #800000aa;
  }

  .btn-primary {
    background-color: #800000;
    border: none;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 10px 28px;
    border-radius: 20px;
    transition: background-color 0.3s ease;
  }

  .btn-primary:hover {
    background-color: #a30000;
  }

  .btn-secondary {
    background-color: #d8c9b3;
    border: none;
    color: #800000;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 10px 28px;
    border-radius: 20px;
    margin-left: 15px;
    transition: background-color 0.3s ease;
  }

  .btn-secondary:hover {
    background-color: #c0b293;
    color: #5a0000;
  }

  @media (max-width: 576px) {
    .edit-form {
      padding: 25px 20px;
      margin: 20px;
    }
  }
</style>

<h2>Edit Produk</h2>
<div class="edit-form">
    <form action="../proses/proses_edit_produk.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($data_produk['ProdukID']); ?>">
        <div class="mb-4">
            <label for="nama_produk" class="form-label">Nama Produk</label>
            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= htmlspecialchars($data_produk['NamaProduk']); ?>" required>
        </div>
        <div class="mb-4">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" class="form-control" id="harga" name="harga" value="<?= htmlspecialchars($data_produk['Harga']); ?>" required>
        </div>
        <div class="mb-4">
            <label for="stok" class="form-label">Stok</label>
            <input type="number" class="form-control" id="stok" name="stok" value="<?= htmlspecialchars($data_produk['Stok']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="produk.php" class="btn btn-secondary">Batal</a>
    </form>
</div>

<?php include '../templates/footer.php'; ?>

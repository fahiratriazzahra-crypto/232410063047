<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Aplikasi Kasir</title>
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />

  <style>
    body {
      background-color: #fef9f4;
    }

    .navbar-custom {
      background-color: #fef5e7;
      box-shadow: 0 4px 10px rgba(128, 0, 0, 0.1);
    }

    .navbar-brand,
    .nav-link,
    .navbar-text {
      color: #800000 !important;
      font-weight: 600;
    }

    .nav-link:hover {
      color: #a30000 !important;
    }

    .btn-logout {
      background-color: #800000;
      border-radius: 50px;
      padding: 5px 10px;
      font-weight: 600;
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .btn-logout:hover {
      background-color: #a30000;
      box-shadow: 0 4px 12px rgba(128, 0, 0, 0.2);
    }

    .navbar-nav {
      align-items: center;
    }

    .navbar-container {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .center-menu {
      margin: 0 auto;
    }

    .navbar-brand img {
      max-height: 30px;
      margin-right: 8px;
    }

    @media (max-width: 768px) {
      .center-menu {
        margin: 10px 0;
      }

      .navbar-nav {
        text-align: center;
      }
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-custom py-2">
    <div class="container navbar-container">
      <a class="navbar-brand d-flex align-items-center" href="../halaman/dashboard.php">
        <!-- Ganti logo.png dengan file logo kamu -->
        <img src="../assets/logo.png" alt="Logo" />
        Aplikasi Kasir
      </a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"
          style="filter: invert(20%) sepia(90%) saturate(3000%) hue-rotate(345deg) brightness(80%) contrast(120%);"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav center-menu">
          <li class="nav-item mx-2">
            <a class="nav-link" href="../halaman/dashboard.php">Dashboard</a>
          </li>
          <li class="nav-item mx-2">
            <a class="nav-link" href="../halaman/penjualan.php">Penjualan</a>
          </li>
          <li class="nav-item mx-2">
            <a class="nav-link" href="../halaman/produk.php">Produk</a>
          </li>
          <?php if ($_SESSION['Level'] == 'administrator'): ?>
            <li class="nav-item mx-2">
              <a class="nav-link" href="../halaman/user.php">Manajemen User</a>
            </li>
          <?php endif; ?>
        </ul>
      </div>

      <div class="d-flex align-items-center">
        <span class="navbar-text mr-3">Hallo, <?= htmlspecialchars($_SESSION['Username']); ?>!</span>
        <a class="btn btn-logout text-white" href="../proses/proses_logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <div class="container mt-4">

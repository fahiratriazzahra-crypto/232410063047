<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Ambil data produk untuk dropdown
$query_produk = "SELECT ProdukID, NamaProduk, Harga, Stok FROM produk WHERE Stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

// Ambil data pelanggan untuk dropdown
$query_pelanggan = "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID != 1";
$result_pelanggan = mysqli_query($koneksi, $query_pelanggan);

include '../template/header.php';
?>

<h2>Transaksi Penjualan</h2>

<form action="../proses/proses_penjualan.php" method="POST">
    <div class="form-group">
        <label for="pelanggan_id">Pelanggan</label>
        <select name="pelanggan_id" class="form-control">
            <option value="1" selected>-- Pilih Pelanggan --</option>
            <?php while($row_pelanggan = mysqli_fetch_assoc($result_pelanggan)): ?>
                <option value="<?= $row_pelanggan['PelangganID']; ?>"><?= $row_pelanggan['NamaPelanggan']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <hr>
    <h4>Pilih Barang</h4>
    <div class="form-row mb-3">
        <div class="col-md-5">
            <label for="produk_input">Produk</label>
            <select id="produk_input" class="form-control">
                <option value="">-- Pilih Produk --</option>
                <?php mysqli_data_seek($result_produk, 0); ?>
                <?php while($row_produk = mysqli_fetch_assoc($result_produk)): ?>
                    <option value="<?= $row_produk['ProdukID']; ?>"
                            data-harga="<?= $row_produk['Harga']; ?>"
                            data-nama="<?= $row_produk['NamaProduk']; ?>"
                            data-stok="<?= $row_produk['Stok']; ?>">
                        <?= $row_produk['NamaProduk']; ?> (Stok: <?= $row_produk['Stok']; ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="jumlah_input">Jumlah</label>
            <input type="number" id="jumlah_input" class="form-control" min="1" value="1">
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <button type="button" class="btn btn-primary btn-block" id="tambah-keranjang">Tambah ke Keranjang</button>
        </div>
    </div>
    
    <hr>
    <h4>Keranjang Belanja</h4>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="keranjang-body">
                </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-right"><strong>Total Harga</strong></td>
                    <td colspan="2"><strong id="total-harga-display">Rp 0</strong></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div id="keranjang-inputs"></div>

    <input type="hidden" name="total_harga" id="total_harga">
    <button type="submit" class="btn btn-success btn-block mt-3" id="simpan-transaksi" disabled>Simpan Transaksi</button>
</form>

<?php
include '../template/footer.php';
?>
<script>
$(document).ready(function() {
    let keranjang = {};

    function hitungTotal() {
        let total = 0;
        for (const id in keranjang) {
            total += keranjang[id].subtotal;
        }
        $('#total-harga-display').text('Rp ' + total.toLocaleString('id-ID'));
        $('#total_harga').val(total);
        
        if (Object.keys(keranjang).length > 0) {
            $('#simpan-transaksi').removeAttr('disabled');
        } else {
            $('#simpan-transaksi').attr('disabled', 'disabled');
        }
    }

    function renderKeranjang() {
        $('#keranjang-body').empty();
        $('#keranjang-inputs').empty();

        for (const id in keranjang) {
            const item = keranjang[id];
            const row = `
                <tr>
                    <td>${item.nama}</td>
                    <td>Rp ${item.harga.toLocaleString('id-ID')}</td>
                    <td>
                        <input type="number" class="form-control jumlah-keranjang" data-id="${item.id}" value="${item.jumlah}" min="1" max="${item.stok}">
                    </td>
                    <td>Rp ${item.subtotal.toLocaleString('id-ID')}</td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm hapus-keranjang" data-id="${item.id}">Hapus</button>
                    </td>
                </tr>
            `;
            $('#keranjang-body').append(row);

            // Tambahkan input hidden untuk dikirim ke PHP
            const inputHidden = `
                <input type="hidden" name="produk_id[]" value="${item.id}">
                <input type="hidden" name="jumlah[]" value="${item.jumlah}">
            `;
            $('#keranjang-inputs').append(inputHidden);
        }
        hitungTotal();
    }

    // Aksi tombol "Tambah ke Keranjang"
    $('#tambah-keranjang').click(function() {
        const produkInput = $('#produk_input');
        const jumlahInput = $('#jumlah_input');

        const produkID = produkInput.val();
        const jumlah = parseInt(jumlahInput.val());
        const harga = parseFloat(produkInput.find('option:selected').data('harga'));
        const nama = produkInput.find('option:selected').data('nama');
        const stok = parseInt(produkInput.find('option:selected').data('stok'));

        if (produkID && jumlah > 0 && jumlah <= stok) {
            if (keranjang[produkID]) {
                const newJumlah = keranjang[produkID].jumlah + jumlah;
                if (newJumlah > stok) {
                    alert('Jumlah melebihi stok yang tersedia!');
                    return;
                }
                keranjang[produkID].jumlah = newJumlah;
                keranjang[produkID].subtotal = newJumlah * harga;
            } else {
                keranjang[produkID] = {
                    id: produkID,
                    nama: nama,
                    harga: harga,
                    jumlah: jumlah,
                    stok: stok,
                    subtotal: harga * jumlah
                };
            }
            renderKeranjang();
        } else if (jumlah > stok) {
            alert('Jumlah melebihi stok yang tersedia!');
        } else {
            alert('Silakan pilih produk dan jumlah yang valid.');
        }
    });

    // Aksi tombol "Hapus" dari keranjang
    $(document).on('click', '.hapus-keranjang', function() {
        const produkID = $(this).data('id');
        delete keranjang[produkID];
        renderKeranjang();
    });

    // Update jumlah di keranjang
    $(document).on('change', '.jumlah-keranjang', function() {
        const produkID = $(this).data('id');
        const newJumlah = parseInt($(this).val());
        const stok = keranjang[produkID].stok;

        if (newJumlah <= 0 || newJumlah > stok) {
            alert('Jumlah tidak valid atau melebihi stok!');
            $(this).val(keranjang[produkID].jumlah);
            return;
        }

        keranjang[produkID].jumlah = newJumlah;
        keranjang[produkID].subtotal = newJumlah * keranjang[produkID].harga;
        renderKeranjang();
    });
});
</script>
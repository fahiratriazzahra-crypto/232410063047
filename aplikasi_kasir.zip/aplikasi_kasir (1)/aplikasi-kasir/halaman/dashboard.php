<?php
include '../fungsi/autentikasi.php';
cekLogin();
include '../config/koneksi.php';

// Mendapatkan Jumlah Produk dari database
$query_produk = "SELECT COUNT(*) AS total_produk FROM produk";
$result_produk = mysqli_query($koneksi, $query_produk);
$data_produk = mysqli_fetch_assoc($result_produk);
$total_produk = $data_produk['total_produk'];

// Mendapatkan Total Transaksi Hari Ini
$tanggal_hari_ini = date("Y-m-d");
$query_penjualan = "SELECT SUM(TotalHarga) AS total_penjualan FROM penjualan WHERE TanggalPenjualan = '$tanggal_hari_ini'";
$result_penjualan = mysqli_query($koneksi, $query_penjualan);
$data_penjualan = mysqli_fetch_assoc($result_penjualan);
$total_penjualan = $data_penjualan['total_penjualan'];

// Jika tidak ada transaksi, total_penjualan akan null, kita ubah menjadi 0
if ($total_penjualan === null) {
    $total_penjualan = 0;
}

include '../template/header.php';
?>

<h2>Selamat datang, <?= $_SESSION['Username']; ?>!</h2>
<p>Anda login sebagai: <strong><?= $_SESSION['Level']; ?></strong></p>
<hr>
<div class="row">
    <div class="col-md-6 mb-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">Jumlah Produk</h5>
                <p class="card-text display-4"><?= $total_produk; ?></p>
                <a href="produk.php" class="btn btn-outline-light">Lihat Detail</a>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title">Total Transaksi Hari Ini</h5>
                <p class="card-text display-4">Rp <?= number_format($total_penjualan, 0, ',', '.'); ?></p>
                <a href="laporan_penjualan_harian.php" class="btn btn-outline-light">Lihat Detail</a>
            </div>
        </div>
    </div>
</div>

<?php
include '../template/footer.php';
?>
<?php
namespace App\Models;
use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table = 'tbl_barang';
    protected $primarykey = 'kode_barang';
    protected $allowedFields = ['kode_barang', 'nama_barang', 'harga_beli', 'stok'];
}

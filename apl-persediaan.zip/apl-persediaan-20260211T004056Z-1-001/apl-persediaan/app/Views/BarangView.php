<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang</title>
</head>
<body>
    <h1> Form Data Barang </h1>
    <form>
        Kode Barang : <input type="text"> <br>
        Nama Barang : <input type="text"> <br>
        Harga       : <input type="text"> <br>
        Stok        : <input type="text"> <br><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
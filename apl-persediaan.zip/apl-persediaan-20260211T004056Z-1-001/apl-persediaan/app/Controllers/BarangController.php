<?php

namespace App\Controllers;
class BarangController extends BaseController
{

    public function __construct()
    {
        $this->model = new \App\Models\BarangModel();
    }

    public function index()
    {
        return view('BarangView');
    }
}
